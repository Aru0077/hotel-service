/*
  Warnings:

  - You are about to drop the column `email` on the `client_profiles` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "client_profiles" DROP COLUMN "email";
